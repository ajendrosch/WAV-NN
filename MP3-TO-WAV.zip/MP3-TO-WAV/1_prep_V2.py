hqwav_directory = './data/HQ-WAV/'
mp3_directory = './data/MP3/'
lqwav_directory = './data/LQ-WAV/'

import data_utils
import os
import soundfile as sf
from keras.models import Sequential
from keras.layers.core import Dense, Activation
from keras.optimizers import Adadelta, SGD, Adagrad
import numpy as np
import scipy.io

#data_utils.convert_folder_to_wav(directory = hqwav_directory, sample_rate = 44100)

output_data = np.zeros( (1,1*4410) )
input_data = np.zeros( (1,3*4410) )

for lq_file in os.listdir(lqwav_directory):
	if not os.path.isfile(hqwav_directory + lq_file):
		break
	print 'Processing ' + lq_file

	hq_data, hq_rate = sf.read(hqwav_directory + lq_file)
	lq_data, lq_rate = sf.read(lqwav_directory + lq_file)

	scipy.io.savemat('lq_data.mat',{'lq_data': lq_data})
	scipy.io.savemat('hq_data.mat',{'hq_data': hq_data})

	lq_cut = lq_data[576:]

	diff = hq_data - lq_cut[:len(hq_data)]

	scipy.io.savemat('diff.mat',{'diff': diff})
	
	lq_lower = 0
	lq_upper = lq_lower + 3*4410

	while(lq_upper<len(hq_data)):
		input_data = np.vstack( (input_data, lq_cut[lq_lower:lq_upper]) )
		output_data = np.vstack( (output_data, hq_data[lq_lower+1*4410:lq_lower+2*4410]) )
		lq_lower += 800
		lq_upper = lq_lower + 3*4410
		
	print output_data.shape
	print input_data.shape


model = Sequential()
model.add(Dense(output_dim=3*4410, input_dim=3*4410))
model.add(Dense(3*4410))
model.add(Dense(1*4410))
model.add(Dense(1*4410))

#adadelta = Adadelta(lr=1.0, rho=0.95, epsilon=1e-08)
sgd = SGD(lr=15, momentum=0.0, decay=0.0, nesterov=False)
#adagrad = Adagrad(lr=0.01, epsilon=1e-08)
model.compile(optimizer=sgd, loss='mse')

model.fit(input_data, output_data, nb_epoch=10, batch_size=32)

print 'Training complete, generating test data...'
lq_data, lq_rate = sf.read(lqwav_directory + 'bass.wav')
test_data = np.zeros( (1,3*4410) )
lq_lower = 1
lq_upper = lq_lower + 3*4410

while(lq_upper<len(hq_data)):
		test_data = np.vstack( (test_data, lq_cut[lq_lower:lq_upper]) )
		lq_lower += 4410 
		lq_upper = lq_lower + 3*4410

output = model.predict(test_data, batch_size=32, verbose=1)

scipy.io.savemat('output.mat',{'output': output})

output_stream = output.reshape(-1,1)
print output_stream.shape
print len(output_stream)

scipy.io.savemat('output_stream.mat',{'output_stream': output_stream})

#data_utils.write_np_as_16bit_wav(X = output.reshape(1,-1), sample_rate = 44100, filename='generated.wav')

	
sf.write('generated.wav', output_stream, 44100)

